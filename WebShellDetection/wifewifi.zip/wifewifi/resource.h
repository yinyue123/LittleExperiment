//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wifewifi.rc
//
#define IDD_WIFEWIFI_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define IDC_EDIT1                       1001
#define IDC_TAB1                        1003
#define IDC_SHUAJI                      1012
#define IDC_EDIT4                       1013
#define IDC_EDIT5                       1014
#define IDC_RADIO1                      1015
#define IDC_RADIO2                      1016
#define IDC_RADIO3                      1017
#define IDC_CHECK1                      1018
#define IDC_IPADDRESS1                  1020
#define IDC_EDIT6                       1021
#define IDC_EDIT7                       1022
#define IDC_PEIZHI                      1023
#define IDC_IPADDRESS2                  1028
#define IDC_IPADDRESS3                  1029
#define IDC_EDIT8                       1030
#define IDC_EDIT9                       1031
#define IDC_ZHUCE                       1032
#define IDC_JIANCE                      1033
#define IDC_EDIT10                      1034
#define IDC_IPADDRESS4                  1035
#define IDC_GUANWANG                    1036
#define IDC_SHENGJI                     1037
#define IDC_STATE1                      1038
#define IDC_STATE2                      1039
#define IDC_STATE3                      1040
#define IDC_STATE4                      1041
#define IDC_STATE5                      1042
#define IDC_STATE6                      1043
#define IDC_STATE7                      1044
#define IDC_STATE8                      1045
#define IDC_STATE9                      1046
#define IDC_STATE10                     1047
#define IDC_PEIZHI1                     1049
#define IDC_PEIZHI2                     1050
#define IDC_JIANCE1                     1051
#define IDC_ZHUCE1                      1052
#define IDC_ZHUCE2                      1053
#define IDC_ZHUCE3                      1054
#define IDC_PEIZHI3                     1056
#define IDC_PEIZHI4                     1057
#define IDC_JIANCE2                     1059
#define IDC_IPADDRESS5                  1060
#define IDC_EDIT2                       1061
#define IDC_EDIT3                       1062
#define IDC_EDIT11                      1063
#define IDC_COMBO1                      1067
#define IDC_COMBO2                      1068

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1069
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
