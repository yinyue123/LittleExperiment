package com.cxmscb.cxm.arobot;

import android.accessibilityservice.AccessibilityService;
import android.annotation.TargetApi;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by cxm on 2016/10/26.
 */
public class MyAccessibilityService extends AccessibilityService {


    String nowPackageName;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Toast.makeText(this,"Service授权成功",Toast.LENGTH_SHORT);
        System.out.println("Service授权成功");
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

        nowPackageName = event.getPackageName().toString();
        //if(nowPackageName.equals("com.example.yy.test")&&MyApplication.getInstance().getFlag()){
        if(nowPackageName.equals("com.hitwh.inet.avpn"/*com.example.yy.test"*/)&&MyApplication.getInstance().getFlag()){
            if(event.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED){
                AccessibilityNodeInfo rootNode = this.getRootInActiveWindow();
                System.out.println("进入消息循环");
                iterateNodesAndHandle(rootNode);
            }
        }


    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private boolean iterateNodesAndHandle(AccessibilityNodeInfo info) {
        System.out.println(info.getChildCount());
        if (info.getChildCount() == 0) {

            if (info.getText() != null /*&& (info.getText().toString().contains("手机号") || info.getText().toString().contains("密码") || info.getText().toString().contains("登录"))*/) {
                System.out.println(info.getText().toString());
                System.out.println("进入第一层");
                if ("手机号".equals(info.getText().toString()) && "android.widget.EditText".equals(info.getClassName())) {
                    Toast.makeText(this, " " + info.getText().toString(), Toast.LENGTH_SHORT).show();
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("scb", MyApplication.getInstance().getUsernameParams());
                    clipboardManager.setPrimaryClip(clipData);
                    //info.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
                    info.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                }
                else if ("密码".equals(info.getText().toString()) && "android.widget.EditText".equals(info.getClassName())) {
                    Toast.makeText(this, " " + info.getText().toString(), Toast.LENGTH_SHORT).show();
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("scb", MyApplication.getInstance().getPasswordParams());
                    clipboardManager.setPrimaryClip(clipData);
                    info.performAction(AccessibilityNodeInfo.ACTION_CLICK);//必须先被点下去才能粘贴，否则没获取焦点无法粘贴上去
                    //info.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
                    info.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                }
                /*if ("密码".equals(info.getText().toString()) && "android.widget.EditText".equals(info.getClassName())) {
                    Toast.makeText(this, " " + info.getText().toString(), Toast.LENGTH_SHORT).show();
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("scc", MyApplication.getInstance().getPasswordParams());
                    clipboardManager.setPrimaryClip(clipData);
                    System.out.println("ClipData"+clipboardManager.getPrimaryClip().toString());
                    info.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                }*/
                /*else if ("密码".equals(info.getText().toString()) && "android.widget.EditText".equals(info.getClassName())) {
                    System.out.println(MyApplication.getInstance().getPasswordParams());
                    Toast.makeText(this, " " + info.getText().toString(), Toast.LENGTH_SHORT).show();
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    ClipData clipData = ClipData.newPlainText("scc", MyApplication.getInstance().getPasswordParams());
                    clipboardManager.setPrimaryClip(clipData);
                    info.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                }*/
                else if ("登录".equals(info.getText().toString()) && "android.widget.Button".equals(info.getClassName())) {
                    //System.out.println("进入第二层");
                    Toast.makeText(this, " " + info.getText().toString(), Toast.LENGTH_SHORT).show();
                    AccessibilityNodeInfo parent = info;
                    while (parent != null) {
                        if (parent.isClickable()) {
                            parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            System.out.println("完成点击");
                            break;
                        }
                        parent = parent.getParent();
                    }
                    MyApplication.getInstance().setFlag(false);
                    return true;
                } else {
                    //MyApplication.getInstance().setFlag(false);
                }
            }
        } else {
            for (int i = 0; i < info.getChildCount(); i++) {
                if (info.getChild(i) != null) {
                    iterateNodesAndHandle(info.getChild(i));
                }
            }
        }
        return false;
    }

    @Override
    public void onInterrupt() {
        Toast.makeText(this,"Service授权中断",Toast.LENGTH_SHORT).show();
    }
}


/*}else if("搜索".equals(info.getText().toString())&&"android.widget.TextView".equals(info.getClassName())){
                    Toast.makeText(this," "+info.getText().toString(),Toast.LENGTH_SHORT).show();
                    AccessibilityNodeInfo parent = info;
                    while (parent!=null){
                        if(parent.isClickable()){
                            parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            break;
                        }
                        parent = parent.getParent();
                    }
                    MyApplication.getInstance().setFlag(false);
                    return true;*/