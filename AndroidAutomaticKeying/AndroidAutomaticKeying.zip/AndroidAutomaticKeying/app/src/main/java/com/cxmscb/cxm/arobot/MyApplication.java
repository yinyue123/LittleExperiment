package com.cxmscb.cxm.arobot;

import android.app.Application;

/**
 * Created by cxm on 2016/10/26.
 */

public class MyApplication extends Application {

    private boolean mFlag;
    private String usernameParams;
    private String passwordParams;

    private static MyApplication myApplication = null;
    public static MyApplication getInstance(){
        return myApplication;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        myApplication = this;
    }

    public boolean getFlag() {
        return mFlag;
    }

    public void setFlag(boolean mFlag) {
        this.mFlag = mFlag;
    }

    public String getUsernameParams() {
        return usernameParams;
    }

    public void setUsernameParams(String params) {
        this.usernameParams = params;
    }

    public String getPasswordParams() {
        return passwordParams;
    }

    public void setPasswordParams(String params) {
        this.passwordParams = params;
    }
}
