<?php
echo str_replace('%2F','/',urlencode($argv[1]));
?>
