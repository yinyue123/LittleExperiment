import sys
print sys.argv
print sys.argv[1]
print sys.argv[2]
print sys.argv[3]
